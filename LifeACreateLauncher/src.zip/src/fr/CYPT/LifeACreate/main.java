package fr.CYPT.LifeACreate;

import java.io.File;

import fr.theshark34.openlauncherlib.launcher.GameInfos;
import fr.theshark34.openlauncherlib.launcher.GameTweak;
import fr.theshark34.openlauncherlib.launcher.GameType;
import fr.theshark34.openlauncherlib.launcher.GameVersion;

public class main  {
	
	public static final GameVersion SC_VERSION = new GameVersion("1.7.10", GameType.V1_7_10);
	public static final GameInfos SC_INFOS = new GameInfos("LifeACreate", SC_VERSION, true, new GameTweak[] {GameTweak.FORGE});
	public static final File SC_DIR = SC_INFOS.getGameDir();
	
		
		
}
