package fr.CYPT.LifeACreate;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import fr.theshark34.openlauncherlib.launcher.util.UsernameSaver;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.colored.SColoredBar;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;

public class LauncherPanel extends JPanel implements SwingerEventListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Image background = Swinger.getResource("bg.png");
	
	private UsernameSaver saver = new UsernameSaver(main.SC_INFOS);
	
	
	
	private JTextField usernameField = new JTextField(saver.getUsername(""));
	/*private JPasswordField passwordField = new JPasswordField();*/
	private JLabel Pseudo = new JLabel("Pseudo : ");
	private STexturedButton playButton = new STexturedButton(Swinger.getResource("multijoueur.png"));
	private STexturedButton quit = new STexturedButton(Swinger.getResource("quitter.png"));
	
	private SColoredBar progressBar = new SColoredBar(new Color(255, 255, 255, 15));
	
	
	public LauncherPanel() {
		this.setLayout(null);
		
		Pseudo.setBounds(450, 254, 265, 42);
		Pseudo.setBorder(null);
		Pseudo.setFont(Pseudo.getFont().deriveFont(20F));
		Pseudo.setForeground(Color.white);
		
		usernameField.setForeground(Color.white);
		usernameField.setFont(usernameField.getFont().deriveFont(20F));
		usernameField.setOpaque(false);
		usernameField.setBorder(null);
		usernameField.setBounds(564, 254, 265, 42);
		
		
		playButton.setBounds(300,500);
		playButton.setSize(600, 100);
		playButton.setBorder(null);
		playButton.addEventListener(this);
		
		
		quit.setBounds(10, 10);
		quit.addEventListener(this);
		
		
		progressBar.setBounds(12, 593,981,20);
		
		
		this.add(progressBar);
		this.add(quit);
		this.add(playButton);
		this.add(usernameField);
		this.add(Pseudo);
		
		
		
		
	}
	
	public void onEvent(SwingerEvent e) {
		if(e.getSource() == playButton) {
			setFieldEnable(false);
			
			if(usernameField.getText().replaceAll(" ", " ").length() == 0) {
				JOptionPane.showMessageDialog(this, "tu vas �tre bannis");
				setFieldEnable(true);
				return;
			}
			
			Thread t = new Thread() {
				@Override
				public void run(){
					System.out.println("nothing");
				}
			};
			
			System.out.println("Connected");
		}
		
		else if(e.getSource() == quit) {
			System.exit(0);
		}
	}
	
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		g.drawImage(background, 0, 0,this.getWidth(), this.getHeight(), this);
	}
	
	public void setFieldEnable(boolean enabled) {
		usernameField.setEnabled(enabled);
	}
}
